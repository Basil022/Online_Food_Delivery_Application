package fds.service;

import fds.entities.Address;

public interface AddressService {
	public Address viewAddressByCustomerId(int customerId);
	public String updateAddress(Address a, int addressId);
}
