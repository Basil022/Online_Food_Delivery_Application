package fds.service;

import java.util.List;

import fds.entities.Bill;

public interface IBillService {
	
	public String addBill(Bill bill, int orderId);
	public String updateBill(int billId, Bill bill);
	public Bill viewBillByBillId(int BillId);
	public List<Bill> viewBillsByCustId(int custId);
	public List<Bill> getAllBills();
}