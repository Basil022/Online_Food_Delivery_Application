package fds.service;

import java.util.List;
import fds.entities.Customer;

public interface ICustomerService {
	public String addCustomer(Customer customer);
	public Customer updateCustomer(int custId, Customer customer);
	public Customer viewCustomerById(int id);
	public List<Customer> viewAllCustomers(); 
}