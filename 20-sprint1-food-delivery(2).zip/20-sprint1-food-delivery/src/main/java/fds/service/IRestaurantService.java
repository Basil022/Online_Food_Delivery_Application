package fds.service;

import java.util.List;

import fds.entities.Restaurant;

public interface IRestaurantService {

	public String addRestaurant(Restaurant res);
	public String removeRestaurantById(int restaurantId);
	public Restaurant updateRestaurant(Restaurant restaurant ,int restaurantId);
	public List<Restaurant> viewRestaurant(String name);
	public Restaurant viewRestaurantById(int restaurantId);
	public List<Restaurant> viewAllRestaurants();
	public List<Restaurant> viewNearByRestaurant(String location);
	public List<Restaurant> viewRestaurantByItemName(String name);
}
