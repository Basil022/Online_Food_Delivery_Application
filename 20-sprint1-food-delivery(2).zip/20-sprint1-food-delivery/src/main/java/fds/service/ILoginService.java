package fds.service;

import fds.entities.Login;

public interface ILoginService {
	public String addLoginDetails(Login l);
	public String login(Login l);
	public String logout(String userName);
	public String updateDetails(Login l, int userId);
}
