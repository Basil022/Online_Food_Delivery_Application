package fds.service;

import java.util.List;
import fds.entities.Item;
import fds.entities.OrderDetails;

public interface IOrderService {
	public String addOrder(OrderDetails order, int cartId);
	public String updateOrder(int orderId, OrderDetails order);
	public OrderDetails viewOrderById(int orderId);
	public List<Item> viewAllOrdersByCustId(int custId);
}
