package fds.service;

import java.util.List;

import fds.entities.Item;

public interface IItemService {
	public String addItem(Item item, int restaurantId, int catId);
	public Item viewItem(int ItemId);
	public String updateItemById(Item item, int itemId);
	public List<Item> viewAllItemsByRestId(int restaurantId);
	public List<Item> viewAllItems(int catId);
	public List<Item> viewAllItemsByName(String name);
}
