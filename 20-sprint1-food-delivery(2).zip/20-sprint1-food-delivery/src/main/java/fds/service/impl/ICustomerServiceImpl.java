package fds.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fds.entities.Customer;
import fds.exception.CustomerNotFoundException;
import fds.repositories.AddressRepository;

import fds.repositories.ICustomerRepository;
import fds.service.ICustomerService;

@Component
@Transactional
public class ICustomerServiceImpl implements ICustomerService{
	
	@Autowired
	private ICustomerRepository iCustomerRepository;
	
	@Autowired
	private AddressRepository addressRepository;

	@Override
	public String addCustomer(Customer customer) {
		customer = iCustomerRepository.save(customer);
		addressRepository.save(customer.getAddress());		
		return "Customer details added";
	}

	@Override
	public Customer updateCustomer(int custId ,Customer customer) {
		Customer c2 = iCustomerRepository.findById(custId).orElseThrow(()->new CustomerNotFoundException("Customer Not Found"));

		c2.setAge(customer.getAge());
		c2.setEmail(customer.getEmail());
		c2.setFirstName(customer.getFirstName());
		c2.setLastName(customer.getLastName());
		c2.setGender(customer.getGender());
		c2.setMobileNumber(customer.getMobileNumber());
		return c2;
	}

	@Override
	public Customer viewCustomerById(int id) {
		return iCustomerRepository.findById(id).orElseThrow(()->new CustomerNotFoundException("Customer Not Found"));
	}

	@Override
	public List<Customer> viewAllCustomers() {
		return iCustomerRepository.findAll();
	}
}
