package fds.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import fds.entities.Category;
import fds.entities.Item;
import fds.entities.Restaurant;
import fds.exception.CategoryNotFoundException;
import fds.exception.ItemNotFoundException;
import fds.exception.RestaurantNotFoundException;
import fds.repositories.ICategoryRepository;
import fds.repositories.IItemRepository;
import fds.repositories.IRestaurantRepository;
import fds.service.IItemService;

@Component
@Transactional
public class IItemServiceImpl implements IItemService{

	@Autowired
	public IItemRepository itemRepository;
	
	@Autowired
	public IRestaurantRepository iRestaurantRepository;
	
	@Autowired
	public ICategoryRepository iCategoryRepository;
	
	@Override
	public String addItem(Item item, int restaurantId, int catId) {
		Restaurant r = iRestaurantRepository.findById(restaurantId).orElseThrow(()->new RestaurantNotFoundException("Restaurant Not Found"));
		item.setRestaurant(r);
		
		Category c = iCategoryRepository.findById(catId).orElseThrow(()->new CategoryNotFoundException("Category Not Found"));
		item.setCategory(c);
		item = itemRepository.save(item);
		return "Item Added";
	}

	@Override
	public Item viewItem(int itemId) {
		return itemRepository.findById(itemId).orElseThrow(()->new ItemNotFoundException("Item Not Found"));
	}

	@Override
	public String updateItemById(Item item, int itemId) {
		Item newItem = itemRepository.findById(itemId).orElseThrow(()->new ItemNotFoundException("Item Not Found"));
		newItem.setCost(item.getCost());
		newItem.setItemName(item.getItemName());
		return "Item Updated";
	}

	@Override
	public List<Item> viewAllItemsByRestId(int restaurantId) {
		List<Item> items = itemRepository.findAll();
		List<Item> itemList = new ArrayList<>();
		
		for(Item i: items) {
			if(i.getRestaurant().getRestaurantId() == restaurantId) {
				itemList.add(i);
			}
		}
		return itemList;
	}

	@Override
	public List<Item> viewAllItems(int catId) {
		Category cat = iCategoryRepository.findById(catId).orElseThrow(()->new CategoryNotFoundException("Category Not Found"));
		return cat.getItemList();
	}

	@Override
	public List<Item> viewAllItemsByName(String ItemName) {
		List<Item> itemList = itemRepository.findAll();
		List<Item> newList = new ArrayList<>();
		for(Item i : itemList) {
			if(i.getItemName().equalsIgnoreCase(ItemName)) {
				newList.add(i);
			}
		}
		return newList;
	}

}
