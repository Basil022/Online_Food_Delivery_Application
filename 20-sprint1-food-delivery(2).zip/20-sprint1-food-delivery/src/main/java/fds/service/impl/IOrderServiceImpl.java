package fds.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import fds.entities.Customer;
import fds.entities.FoodCart;
import fds.entities.Item;
import fds.entities.OrderDetails;
import fds.exception.CustomerNotFoundException;
import fds.exception.OrderNotFoundException;
import fds.exception.CartNotFoundException;
import fds.repositories.ICartRepository;
import fds.repositories.ICustomerRepository;
import fds.repositories.IOrderRepository;
import fds.service.IOrderService;

@Component
@Transactional
public class IOrderServiceImpl implements IOrderService{

	@Autowired
	public IOrderRepository iOrderRepository;
	
	@Autowired
	public ICustomerRepository iCustomerRepository;
	
	@Autowired
	public ICartRepository icartrepo;
	
	@Override
	public String addOrder(OrderDetails order, int cartId) {
		FoodCart f = icartrepo.findById(cartId).orElseThrow(()-> new CartNotFoundException("Cart not found"));
		order.setCart(f);
		order = iOrderRepository.save(order);
		return "Order Added";
	}

	@Override
	public String updateOrder(int orderId, OrderDetails order) {
		OrderDetails ord = iOrderRepository.findById(orderId).orElseThrow(()-> new OrderNotFoundException("Order not found"));
		ord.setOrderDate(order.getOrderDate());
		ord.setOrderStatus(order.getOrderStatus());
		return "Order Updated";
	}

	@Override
	public OrderDetails viewOrderById(int orderId) {
		return iOrderRepository.findById(orderId).orElseThrow(()-> new OrderNotFoundException("Order not found"));
	}

	@Override
	public List<Item> viewAllOrdersByCustId(int custId) {
		Customer c = iCustomerRepository.findById(custId).orElseThrow(()-> new CustomerNotFoundException("Customer not found"));
		return c.getFoodCart().getItemList();
	}

}
