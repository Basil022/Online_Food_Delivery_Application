package fds.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import fds.entities.Login;
import fds.exception.LoginException;
import fds.repositories.ILoginRepository;
import fds.service.ILoginService;

@Component
@Transactional
public class ILoginServiceImpl implements  ILoginService{

	@Autowired
	private ILoginRepository loginRepo;
	
	@Override
	public String login(Login l) {
		String password = l.getPassword();
		String userName = l.getUserName();
		Login l1 = loginRepo.findByUserName(userName);
		if(l1 == null) {
			throw new LoginException("Invalid credentials");
		}
		else if(!l1.getPassword().equals(password) || !l1.getUserName().equals(userName)) {
			throw new LoginException("Invalid Exceptions");
		}
		return "Login Successful...";
	}

	@Override
	public String logout(String userName) {
		Login l = loginRepo.findByUserName(userName);
		if(l==null) {
			throw new LoginException("Invalid User Name");
		}
		return "Logout successful";
	}

	@Override
	public String addLoginDetails(Login l) {
		l.setUserName(l.getUserName().toLowerCase());
		l = loginRepo.save(l);
		return "User details added";
	}

	@Override
	public String updateDetails(Login l, int userId) {
		Login l2 = loginRepo.findById(userId).orElseThrow(()-> new LoginException("Invalid user id"));
		l2.setPassword(l.getPassword());
		l2.setUserName(l.getUserName());
		return "Login details updated";
	}
}
