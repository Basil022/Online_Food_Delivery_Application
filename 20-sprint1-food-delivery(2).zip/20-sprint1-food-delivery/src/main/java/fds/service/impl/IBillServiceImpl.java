package fds.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import fds.entities.Bill;
import fds.entities.Customer;
import fds.entities.FoodCart;
import fds.entities.Item;
import fds.entities.OrderDetails;
import fds.exception.BillNotFoundException;
import fds.exception.CustomerNotFoundException;
import fds.exception.OrderNotFoundException;
import fds.repositories.IBillRepository;
import fds.repositories.ICustomerRepository;
import fds.repositories.IOrderRepository;
import fds.service.IBillService;

@Component
@Transactional
public class IBillServiceImpl implements IBillService{

	@Autowired
	public IBillRepository ibillRepository;
	
	@Autowired
	public ICustomerRepository iCustomerRepository;
	
	@Autowired
	public IOrderRepository iorderRepositoy;

	@Override
	public String addBill(Bill bill, int orderId) {
		
		OrderDetails order = iorderRepositoy.findById(orderId).orElseThrow(()-> new OrderNotFoundException("Order not found"));
		FoodCart cart = order.getCart();
		bill.setTotalItems(cart.getItemList().size());
		
		double totalcost = 0.0;
		for(Item i: cart.getItemList()) {
			totalcost += i.getCost();
		}
		bill.setOrder(order);
		bill.setTotalCost(totalcost);
		bill = ibillRepository.save(bill);
		return "Bill Saved";
	}

	@Override
	public String updateBill(int billId, Bill bill) {
		Bill b = ibillRepository.findById(billId).orElseThrow(()-> new BillNotFoundException("Bill not found"));
		b.setBillId(bill.getBillId());
		b.setBillDate(bill.getBillDate());
		b.setTotalCost(bill.getTotalCost());
		b.setTotalItems(bill.getTotalItems());
		return "Bill Updated";
	}

	@Override
	public Bill viewBillByBillId(int billId) {
		Bill bill = ibillRepository.findById(billId).orElseThrow(()-> new BillNotFoundException("Bill not found"));	
		return bill;
	}

	@Override
	public List<Bill> viewBillsByCustId(int custId) {
		
		Customer c = iCustomerRepository.findById(custId).orElseThrow(()->new CustomerNotFoundException("Customer Not Found"));
		List<Item> itemList = c.getFoodCart().getItemList();
		Bill bill = new Bill();
		
		double totalCost = 0.0;
		for(Item i: itemList) {
			totalCost+=i.getCost();
		}
		
		bill.setTotalCost(totalCost);
		bill.setTotalItems(itemList.size());
		
		List<Bill> billList = new ArrayList<>();
		billList.add(bill);
		return billList;
	}

	@Override
	public List<Bill> getAllBills() {
		List<Bill> billList = ibillRepository.findAll();
		return billList;
	}

}
