package fds.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import fds.entities.Category;
import fds.entities.Item;
import fds.exception.CategoryNotFoundException;
import fds.exception.ItemNotFoundException;
import fds.repositories.ICategoryRepository;
import fds.repositories.IItemRepository;
import fds.service.ICategoryService;

@Component
@Transactional
public class ICategoryServiceImpl implements ICategoryService{

	@Autowired
	public ICategoryRepository iCategoryRepository;
	
	@Autowired
	public IItemRepository itemRepository;
	
	@Override
	public String addCategory(Category car) {
		car=iCategoryRepository.save(car);
		return "Category Added";
	}

	@Override
	public String updateCategory(Category cat, int categoryId) {
		System.out.println(categoryId);
		Category c1 = iCategoryRepository.findById(categoryId).orElseThrow(()-> new CategoryNotFoundException("Category Not Found"));
		c1.setCategoryName(cat.getCategoryName());
		iCategoryRepository.updateCategoryName(cat.getCategoryName(), categoryId);
		return "Category Updated";
	}

	@Override
	public String removeCategory(int categoryId) {
		iCategoryRepository.findById(categoryId).orElseThrow(()-> new CategoryNotFoundException("Category Not Found"));
		iCategoryRepository.deleteById(categoryId);
		return "Category Deleted";
	}

	@Override
	public Category viewCategoryByItemId(int itemId) {
		Item item = itemRepository.findById(itemId).orElseThrow(()-> new ItemNotFoundException("Item Not Found"));
		return item.getCategory();
	}

	@Override
	public List<Category> viewAllCategory() {
		return iCategoryRepository.findAll();
	}

	@Override
	public Category viewCategoryByCatId(int catId) {
		return iCategoryRepository.findById(catId).orElseThrow(()-> new CategoryNotFoundException("Category Not Found"));
	}

}
