package fds.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fds.entities.Address;
import fds.entities.Customer;
import fds.exception.AddressNotFoundException;
import fds.exception.CustomerNotFoundException;
import fds.repositories.AddressRepository;
import fds.repositories.ICustomerRepository;
import fds.service.AddressService;

@Component
@Transactional
public class AddressServiceImpl implements AddressService{

	@Autowired
	private ICustomerRepository icustomerRepository;
	
	@Autowired
	private AddressRepository addressRepository;

	@Override
	public Address viewAddressByCustomerId(int customerId) {
		Customer c = icustomerRepository.findById(customerId).orElseThrow(()->new CustomerNotFoundException("Customer Not Found"));
		return c.getAddress();
	}

	@Override
	public String updateAddress(Address a, int addressId) {
		Address a1 = addressRepository.findById(addressId).orElseThrow(()->new AddressNotFoundException("Address Not Found"));
		a1.setArea(a.getArea());
		a1.setBuildingName(a.getBuildingName());
		a1.setCity(a.getCity());
		a1.setCountry(a.getCountry());
		a1.setPincode(a.getPincode());
		a1.setState(a.getState());
		a1.setStreetNo(a.getStreetNo());
		return "Address Updated";
	}
}
