package fds.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import fds.entities.Customer;
import fds.entities.FoodCart;
import fds.entities.Item;
import fds.exception.CartNotFoundException;
import fds.exception.CustomerNotFoundException;
import fds.exception.ItemNotFoundException;
import fds.repositories.ICartRepository;
import fds.repositories.ICustomerRepository;
import fds.repositories.IItemRepository;
import fds.service.ICartService;

@Component
@Transactional
public class ICartServiceImpl implements ICartService {
	
	@Autowired
	public ICustomerRepository custrepo;
	
	@Autowired
	public IItemRepository itemRepository;
	
	@Autowired
	public ICartRepository iCartRepository;
	
	@Override
	public String createFoodCart(FoodCart cart, int customerId) {
		Customer c = custrepo.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer not found"));
		c.setFoodCart(cart);
		c.setCustomerId(customerId);
		cart.setCustomer(c);
		cart = iCartRepository.save(cart);
		return "Food Cart Created";
	}
	
	@Override
	public String addItemToCart(int custId, int itemId) {
		Item item = itemRepository.findById(itemId).orElseThrow(()-> new ItemNotFoundException("Item not found"));
		Customer c = custrepo.findById(custId).orElseThrow(()-> new CustomerNotFoundException("Customer not found"));
		c.getFoodCart().getItemList().add(item);
		return "Item added to cart";
	}

	@Override
	public String removeItem(int customerId, int itemId) {
		Item item = itemRepository.findById(itemId).orElseThrow(()-> new ItemNotFoundException("Item not found"));		
		Customer c = custrepo.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer not found"));
		if(c.getFoodCart().getItemList().contains(item)) {
			c.getFoodCart().getItemList().remove(item);
		} else {
			throw new ItemNotFoundException("Item not found");
		}
		return "Item removed";
	}
	
	@Override
	public List<Item> viewAllItemsinCart(int custId) {
		Customer c = custrepo.findById(custId).orElseThrow(()-> new CustomerNotFoundException("Customer not found"));
		List<Item> itemList = c.getFoodCart().getItemList();
		return itemList;
	}

	@Override
	public String clearCart(int customerId) {
		Customer c = custrepo.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer not found"));
		c.getFoodCart().getItemList().clear();
		return "Food Cart Cleared";
	}

	@Override
	public FoodCart viewCartByCartId(int cartId) {
		FoodCart c = iCartRepository.findById(cartId).orElseThrow(()-> new CartNotFoundException("Cart not found"));
		return c;
	}
}