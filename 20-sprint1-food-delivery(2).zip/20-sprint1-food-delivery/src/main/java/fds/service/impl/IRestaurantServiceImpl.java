package fds.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fds.entities.Item;
import fds.entities.Restaurant;
import fds.exception.RestaurantNotFoundException;
import fds.repositories.AddressRepository;
import fds.repositories.IItemRepository;
import fds.repositories.IRestaurantRepository;
import fds.service.IRestaurantService;

@Component
@Transactional
public class IRestaurantServiceImpl implements IRestaurantService{

	@Autowired
	private IRestaurantRepository iRestaurantRepository;
	
	@Autowired
	private AddressRepository addressRepository;
	
	@Autowired
	private IItemRepository itemRepository;
	
	@Override
	public String addRestaurant(Restaurant restaurant) {
		restaurant.setRestaurantName(restaurant.getRestaurantName().toLowerCase());
		restaurant = iRestaurantRepository.save(restaurant);
		addressRepository.save(restaurant.getAddress());
		return "Restaurant details added";
	}
	
	@Override
	public String removeRestaurantById(int restaurantId) {
		iRestaurantRepository.findById(restaurantId).orElseThrow(()->new RestaurantNotFoundException("Restaurant Not Found"));
		iRestaurantRepository.deleteById (restaurantId) ;      
		return"Restaurant details deleted";
	}

	@Override
	public Restaurant updateRestaurant(Restaurant restaurant, int restaurantId ) {
		Restaurant r = iRestaurantRepository.findById(restaurantId).orElseThrow(()->new RestaurantNotFoundException("Restaurant Not Found"));
		r.setRestaurantName(restaurant.getRestaurantName());
		r.setContactNumber(restaurant.getContactNumber());
		r.setManagerName(restaurant.getManagerName());
		return r;
	}

	@Override
	public List<Restaurant> viewRestaurant(String restaurantName) {
		return iRestaurantRepository.findByRestaurantName(restaurantName);
	}

	@Override
	public List<Restaurant> viewAllRestaurants() {
		List<Restaurant> restaurantList = iRestaurantRepository.findAll();
		return restaurantList;
	}

	@Override
	public List<Restaurant> viewNearByRestaurant(String location) {
		List<Restaurant> nearByRestaurants = new ArrayList<>();
		List<Restaurant> restaurantList = iRestaurantRepository.findAll();
		for(Restaurant r: restaurantList) {
			if(r.getAddress().getArea().equalsIgnoreCase(location)) {
				nearByRestaurants.add(r);
			}
		}
		return nearByRestaurants;
	}

	@Override
	public List<Restaurant> viewRestaurantByItemName(String itemName) {
		List<Restaurant> itemRestaurant = new ArrayList<>();		
		List<Item> itemList = itemRepository.findAll();
		for(Item i: itemList) {
			if(i.getItemName().equalsIgnoreCase(itemName)) {
				itemRestaurant.add(i.getRestaurant());
			}
		}
		return itemRestaurant;
	}

	@Override
	public Restaurant viewRestaurantById(int restaurantId) {
		return iRestaurantRepository.findById(restaurantId).orElseThrow(()->new RestaurantNotFoundException("Restaurant Not Found"));
	}

}
