package fds.service;

import java.util.List;

import fds.entities.Category;

public interface ICategoryService {
	public String addCategory(Category car);
	public String updateCategory(Category car, int categoryId);
	public String removeCategory(int categoryId);
	public Category viewCategoryByItemId(int itemId);
	public List<Category> viewAllCategory();
	public Category viewCategoryByCatId(int catId);
}
