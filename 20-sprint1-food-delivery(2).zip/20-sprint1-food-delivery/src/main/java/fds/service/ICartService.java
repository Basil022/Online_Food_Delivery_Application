package fds.service;

import java.util.List;

import fds.entities.FoodCart;
import fds.entities.Item;

public interface ICartService {
	public String createFoodCart(FoodCart cart, int customerId);
	public String addItemToCart(int customerId, int itemId);
	public String removeItem(int customerId, int itemId);
	public String clearCart(int customerId);
	public List<Item> viewAllItemsinCart(int custId);
	public FoodCart viewCartByCartId(int cartId);
}
