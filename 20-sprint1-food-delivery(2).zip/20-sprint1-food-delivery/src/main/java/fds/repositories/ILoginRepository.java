package fds.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import fds.entities.Login;

public interface ILoginRepository extends JpaRepository<Login, Integer>{
	public Login findByUserName(String userName);

}
