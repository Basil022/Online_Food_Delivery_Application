package fds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fds.entities.Restaurant;
import fds.service.IRestaurantService;
@RestController
@RequestMapping("/restaurant")
public class RestaurantController {
		
	@Autowired
	private IRestaurantService restService;
	     
	@RequestMapping("/test")
	public Restaurant testApi(){
		Restaurant rest = new Restaurant();
		rest.setManagerName("Rachana");
		rest.setRestaurantName("hyd chefs");
		rest.setContactNumber("7554");
		return rest;
	}
	@PostMapping
	public String addRestaurant(@RequestBody  Restaurant rest ){
		return restService.addRestaurant(rest);
	}	
	
	@GetMapping("/get/{restName}")
	public List<Restaurant> viewRestaurant(@PathVariable("restName") String restaurantName) {
		return restService.viewRestaurant(restaurantName);
	}
	@PutMapping("/{restaurantId}")
	public  Restaurant updateCustomer(@PathVariable("restaurantId") int restaurantId,@RequestBody Restaurant rest) {
		return restService.updateRestaurant(rest, restaurantId);
	}
	@DeleteMapping("/{restaurantId}")
	public String removeById(@PathVariable("restaurantId") int restaurantId) {
		return restService.removeRestaurantById(restaurantId);
	}
	@GetMapping("/{restaurantId}")
	public Restaurant viewRestaurantById(@PathVariable("restaurantId")int restaurantId) {
		return restService.viewRestaurantById(restaurantId);
	}
	@GetMapping
	public List<Restaurant> viewAllRestaurants(){
		return restService.viewAllRestaurants();
	}
	@GetMapping("location/{location}")
	public List<Restaurant> viewAllNearByRestaurants(@PathVariable("location") String location){
		return restService.viewNearByRestaurant(location);
	}
	@GetMapping("/item/{itemName}")
	public List<Restaurant> viewRestaurantbyItemName(@PathVariable("itemName") String itemName){
		return restService.viewRestaurantByItemName(itemName);
	}
}