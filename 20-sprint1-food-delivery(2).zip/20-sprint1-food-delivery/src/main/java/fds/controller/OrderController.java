package fds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fds.entities.Item;
import fds.entities.OrderDetails;
import fds.service.IOrderService;

@RestController
@RequestMapping("/customers/{custId}/order")
public class OrderController {

	@Autowired
	public IOrderService iorderService;
	
	@PostMapping("/{cartId}")
	public String addNewOrder(@RequestBody OrderDetails order, @PathVariable("cartId") int cartId) {
		return iorderService.addOrder(order, cartId);
	}
	
	@PutMapping("/update/{orderId}")
	public String updateOrder(@PathVariable("orderId") int orderId, @RequestBody OrderDetails order) {
		return iorderService.updateOrder(orderId, order);
	}
	
	@GetMapping("/{orderId}")
	public OrderDetails getOrderDetails(@PathVariable("orderId") int orderId) {
		return iorderService.viewOrderById(orderId);
	}
	
	@GetMapping
	public List<Item> viewOrderByCustId(@PathVariable("custId") int custId){
		return iorderService.viewAllOrdersByCustId(custId);
	}
}
