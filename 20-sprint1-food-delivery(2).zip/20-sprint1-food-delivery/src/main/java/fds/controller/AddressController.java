package fds.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fds.entities.Address;
import fds.service.AddressService;

@RestController
@RequestMapping("customers/address")
public class AddressController {
	
	@Autowired
	private AddressService addService;
	
	@GetMapping
	public Address viewAddressByCustId(@PathVariable("customerId") int customerId) {
		return addService.viewAddressByCustomerId(customerId);
	}
	
	@PutMapping("/{addressId}")
	public String updateAddress(@RequestBody Address a, @PathVariable("addressId") int addressId) {
		return addService.updateAddress(a, addressId);
	}
}
