package fds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fds.entities.Category;
import fds.service.ICategoryService;

@RestController
@RequestMapping("/restaurant/category")
public class ICategoryController {

	@Autowired
	private ICategoryService icategoryService;
	
	@RequestMapping("/test")
	public Category testApi() {
		Category cat = new Category();
		cat.setCatId(1);
		cat.setCategoryName("Dosa");
		return cat;
	}
	
	@PostMapping
	public String addCategory(@RequestBody Category c) {
		return icategoryService.addCategory(c);
	}
	
	@PutMapping("/{categoryId}")
	public String updateCategory(@PathVariable("categoryId") int categoryId, @RequestBody Category c) {
		return icategoryService.updateCategory(c, categoryId);
	}
	
	@DeleteMapping("/{categoryId}")
	public String removeCategory(@PathVariable("categoryId") int categoryId) {
		return icategoryService.removeCategory(categoryId);
	}
	
	@GetMapping("/{itemId}")
	public Category viewCategoryByItemId(@PathVariable("itemId") int itemId) {
		return icategoryService.viewCategoryByItemId(itemId);
	}
	
	@GetMapping
	public List<Category> viewAllCategory(){
		return icategoryService.viewAllCategory();
	}
}
