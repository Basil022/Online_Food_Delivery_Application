package fds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fds.entities.Bill;
import fds.service.IBillService;

@RestController
@RequestMapping("customers/{custId}/order")
public class BillController {
	
	@Autowired
	private IBillService billService;
	
	@PostMapping("/{orderId}/bill")
	public String addBillByOrderId(@RequestBody Bill bill, @PathVariable("orderId") int orderId) {
		return billService.addBill(bill, orderId);
	}
	
	@PutMapping("/{billId}")
	public String updateBill(@PathVariable("billId") int billId, @RequestBody Bill bill) {
		return billService.updateBill(billId, bill);
	}

	@GetMapping("/bill")
	public List<Bill> viewBillByCustId(@PathVariable("custId") int custId) {
		return billService.viewBillsByCustId(custId);
	}
	
	@GetMapping("/bill/{bill}")
	public Bill viewBillByBillId(@PathVariable("bill") int billId) {
		return billService.viewBillByBillId(billId);
	}
	
	@GetMapping("/bills/all")
	public List<Bill> viewAllBills(){
		return billService.getAllBills();
	}
}
