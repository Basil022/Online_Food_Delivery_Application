package fds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fds.entities.Customer;
import fds.service.ICustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {

	@Autowired
	private ICustomerService custService;
     
	@RequestMapping("/test")
	public Customer testApi(){
	
		Customer c = new Customer();
		c.setCustomerId(101);
		c.setFirstName("Basil");
		c.setLastName("Rasheed");
		c.setAge(22);
		c.setGender("Male");
		c.setMobileNumber("9740356618");
		c.setEmail("basil@cg.com");
		return c;
	}
	@PostMapping
	public String addCustomer(@RequestBody Customer c){
		return custService.addCustomer(c);
	}
	
	@GetMapping("/{custId}")
	public Customer viewCustomerId(@PathVariable("custId") int custcode){
		return custService.viewCustomerById(custcode);
	}
	
	@PutMapping("/{custId}")
	public Customer updateCustomer(@PathVariable("custId") int custId, @RequestBody Customer c) {
		return custService.updateCustomer(custId, c);
	}
	
	@GetMapping
	public List<Customer> viewAllCustomers(){
		return custService.viewAllCustomers();
	}
}