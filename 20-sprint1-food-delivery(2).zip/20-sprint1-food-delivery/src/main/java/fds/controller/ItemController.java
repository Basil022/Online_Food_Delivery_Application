package fds.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fds.entities.Item;
import fds.service.IItemService;

@RestController
@RequestMapping("restaurant/{restaurantId}/items")
public class ItemController {

	@Autowired
	private IItemService itemService;
	
	@PostMapping("/category/{catId}")
	public String addItem(@RequestBody Item item, @PathVariable("restaurantId") int restaurantId, @PathVariable("catId") int catId) {
		return itemService.addItem(item, restaurantId, catId);
	}
	@GetMapping("/{itemId}")
	public Item viewItem(@PathVariable("itemId") int itemId) {
		return itemService.viewItem(itemId);
	}
	@PutMapping("/{itemId}")
	public String updateItemById(@RequestBody Item item, @PathVariable("itemId") int itemId) {
		return itemService.updateItemById(item, itemId);
	}
	
	@GetMapping
	public List<Item> viewItemByRestaurantId(@PathVariable("restaurantId") int restaurantId){
		return itemService.viewAllItemsByRestId(restaurantId);
	}
	
	@GetMapping("/get/{itemName}")
	public List<Item> viewAllItemsByName(@PathVariable("itemName") String itemName){
		return itemService.viewAllItemsByName(itemName);
	}
	
	@GetMapping("/category/{catId}")
	public List<Item> viewAllItemInCategory(@PathVariable("catId") int catId){
		return itemService.viewAllItems(catId);
	}
}
