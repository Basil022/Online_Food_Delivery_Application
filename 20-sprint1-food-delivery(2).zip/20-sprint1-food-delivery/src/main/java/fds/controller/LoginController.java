package fds.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import fds.entities.Login;
import fds.service.ILoginService;

@RestController
@RequestMapping
public class LoginController {
	
	@Autowired
	private ILoginService loginService;
	
	@PostMapping("login/id")
	public String addLoginDetails(@RequestBody Login l) {
		return loginService.addLoginDetails(l);
	}
	
	@PutMapping("customer/login")
	public String customerLogin(@RequestBody Login l) {
		return loginService.login(l);
	}
	
	@GetMapping("/logout/{username}")
	public String logout(@PathVariable("username") String userName) {
		return loginService.logout(userName);
	}
	
	@PutMapping("restaurant/login")
	public String restaurantLogin(@RequestBody Login l) {
		return loginService.login(l);
	}
}
