package fds.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class LogoutException extends RuntimeException{
	public LogoutException() {
		
	}
	public LogoutException(String msg) {
		super(msg);
	}
}
