package fds.exception;

public class RestaurantNotFoundException extends RuntimeException{
	public RestaurantNotFoundException() {
		
	}
	public RestaurantNotFoundException(String msg) {
		super(msg);
	}

}