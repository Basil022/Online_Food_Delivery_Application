package fds.exception;

public class BillNotFoundException extends RuntimeException{
	public BillNotFoundException() {
		
	}
	public BillNotFoundException(String msg) {
		super(msg);
	}

}