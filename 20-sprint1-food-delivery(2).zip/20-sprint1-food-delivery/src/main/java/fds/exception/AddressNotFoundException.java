package fds.exception;

public class AddressNotFoundException extends RuntimeException{
	public AddressNotFoundException() {
		
	}
	public AddressNotFoundException(String msg) {
		super(msg);
	}

}