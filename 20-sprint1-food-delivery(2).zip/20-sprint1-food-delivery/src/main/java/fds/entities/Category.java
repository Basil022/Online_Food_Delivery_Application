package fds.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Category {
	@Id
	@GeneratedValue
	private int categoryId;
	private String categoryName;
	
	@OneToMany(mappedBy="category")
	private List<Item> itemList;
	
	public List<Item> getItemList() {
		return itemList;
	}

	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}

	public Category() {
		
	}
	
	public Category(int catId, String categoryName) {
		super();
		this.categoryId = catId;
		this.categoryName = categoryName;
	}

	public int getCatId() {
		return categoryId;
	}

	public void setCatId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
}
