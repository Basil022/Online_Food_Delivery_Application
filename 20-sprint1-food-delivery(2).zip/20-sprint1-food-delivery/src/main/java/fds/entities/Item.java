package fds.entities;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class Item {

	@Id
	@GeneratedValue
	private int itemId;
	private String itemName;
	private double cost;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="restaurantId")
	@JsonIgnore
	private Restaurant restaurant;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="categoryId")
	@JsonIgnore
	private Category category;
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	public Item() {
		
	}
	
	public Item(int itemId, String itemName, Category category, double cost, 
			Restaurant restaurant) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.category = category;
		this.cost = cost;
		this.restaurant = restaurant;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
}