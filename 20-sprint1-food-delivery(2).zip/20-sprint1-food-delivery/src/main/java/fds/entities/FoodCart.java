package fds.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity(name="foodcart")
@Table(name="foodcart")
public class FoodCart {

	@Id
	private int cartId;

	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customerId")
	@JsonIgnore
	private Customer customer;
	
	@OneToMany(targetEntity=Item.class, cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	private List<Item> itemList;
	
	public FoodCart() {
		
	}
	
	public FoodCart(int cartId, List<Item> itemList) {
		super();
		this.cartId = cartId;
		this.itemList = itemList;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public List<Item> getItemList() {
		return itemList;
	}

	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
}
