package fds.sprint1fooddelivery;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import fds.entities.Address;
import fds.entities.Customer;
import fds.repositories.ICustomerRepository;
import fds.service.impl.ICustomerServiceImpl;

public class CustomerTests {
	@InjectMocks
	ICustomerServiceImpl custServiceImpl;
	
	@Mock
	ICustomerRepository custRepo;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	void testCustomer() {
		Address a = new Address(1,"CG", "Whitefield", 234, "Bangalore", "Karnataka", "India", 56006);
		Customer c1 =new Customer(101, "Basil", "Rasheed", "Male", 22, "9740356618", "basil@cg.com",a, null);
		
		Mockito.when(custRepo.findById(101)).thenReturn(Optional.of(c1));
		Customer c2=custServiceImpl.viewCustomerById(101);
		assertEquals(c1.getFirstName(), c2.getFirstName());
	}
	
	@Test
	void testGetAllCustomer() {
	  //Mock data
	  Customer c1 = new Customer(101, "Basil", "Rasheed", "Male", 22, "9740356618", "basil@cg.com",null, null);
	  Customer c2 = new Customer(102,  "Balaji", "K", "Male", 22, "9876543210", "balaji@cg.com",null, null);
	  Customer c3 = new Customer(103,  "Navya", "S", "Female", 22, "1234567890", "navya@cg.com",null, null);
	  Customer c4 = new Customer(104,  "Akhila", "N", "Female", 22, "5678904321", "akhila@cg.com",null, null);
	  List<Customer> list=new ArrayList<Customer>();
	  list.add(c1);  list.add(c2);  list.add(c3);  list.add(c4);
	   
	  Mockito.when(custRepo.findAll()).thenReturn(list);
	  
	  List<Customer> list2=custServiceImpl.viewAllCustomers();
	  assertEquals(list.size(), list2.size());
	}
}
