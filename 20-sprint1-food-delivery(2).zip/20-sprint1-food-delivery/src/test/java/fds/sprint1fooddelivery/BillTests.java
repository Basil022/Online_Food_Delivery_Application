package fds.sprint1fooddelivery;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import fds.entities.Bill;
import fds.repositories.IBillRepository;
import fds.service.impl.IBillServiceImpl;

public class BillTests {
	@InjectMocks
	IBillServiceImpl billServiceImpl;
	
	@Mock
	IBillRepository billRepo;
	
	@Test
	void contextLoads() {
	}
  
	@Test
	void testBill() {
		Bill b1 = new Bill(1, null, 5, 200.0, "15-02-2023");
		Mockito.when(billRepo.findById(1)).thenReturn(Optional.of(b1));
	  
		Bill b2 = billServiceImpl.viewBillByBillId(1);
		assertEquals(b1.getTotalCost(), b2.getTotalCost());
	}
	@Test
	void testGetAllBills() {
		Bill b1 = new Bill(1, null, 5, 200.0, "15-02-2023");
		Bill b2 = new Bill(2, null, 6, 100.0, "16-02-2023");
		Bill b3 = new Bill(3, null, 7, 300.0, "17-02-2023");
		Bill b4 = new Bill(4, null, 8, 400.0, "18-02-2023");
		List<Bill> list = new ArrayList<Bill>();
		list.add(b1); list.add(b2); list.add(b3); list.add(b4);
	  
		Mockito.when(billRepo.findAll()).thenReturn(list);
	  
		List<Bill> list2 = billServiceImpl.getAllBills();
		assertEquals(list.size(), list2.size());
	}
}
