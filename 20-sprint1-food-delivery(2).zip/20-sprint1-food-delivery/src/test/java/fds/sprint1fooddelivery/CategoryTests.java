package fds.sprint1fooddelivery;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import fds.entities.Category;
import fds.repositories.ICategoryRepository;
import fds.service.impl.ICategoryServiceImpl;

public class CategoryTests {
	@InjectMocks
	ICategoryServiceImpl catServiceImpl;
	
	@Mock
	ICategoryRepository catRepo;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	  void testCategory() {
		  Category c1 = new Category(1, "pizza");
		  Mockito.when(catRepo.findById(1)).thenReturn(Optional.of(c1));
		  
		  Category c2 = catServiceImpl.viewCategoryByCatId(1);
		  assertEquals(c1.getCategoryName() , c2.getCategoryName());
	  }
	  @Test
	  void testGetAllCategories() {
		  Category c1 = new Category(1, "Pizza");
		  Category c2 = new Category(2, "Biryani");
		  Category c3 = new Category(3, "Dosa");
		  Category c4 = new Category(4, "Paneer");
		  List<Category> list = new ArrayList<Category>();
		  list.add(c1); list.add(c2); list.add(c3); list.add(c4);
		  
		  Mockito.when(catRepo.findAll()).thenReturn(list);
		  
		  List<Category> list2 = catServiceImpl.viewAllCategory();
		  assertEquals(list.size(), list2.size());
	  }
}
